# Коллекционная карточная игра на Unity
Коллекционная карточная игра на Unity by def1NeX

Плейлист с видеоуроками: https://www.youtube.com/playlist?list=PL0isw1lWHi7v1Nz91eGEnqDIAI8y9dgoN
